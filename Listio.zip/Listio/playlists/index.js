'use strict';

const {Playlist} = require('./models');
const {router} = require('./router');

module.exports = {Playlist, router};
